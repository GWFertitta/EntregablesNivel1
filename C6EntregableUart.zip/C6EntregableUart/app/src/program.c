/*============================================================================
 * Licencia:
 * Autor:Guillermo Fertitta
 * Fecha:07/09/17
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

//#include "program.h"   // <= su propio archivo de cabecera (opcional)
#include "sapi.h"        // <= Biblioteca sAPI

//#include "c_i18n_es.h" // <= para traducir el codigo C al espa�ol (opcional)
//#include "c_i18n_es.h" // <= para traducir la sAPI al espa�ol (opcional)

/*==================[definiciones y macros]==================================*/

/*==================[definiciones de datos internos]=========================*/

CONSOLE_PRINT_ENABLE

/*==================[definiciones de datos externos]=========================*/

/*==================[declaraciones de funciones internas]====================*/

/*==================[declaraciones de funciones externas]====================*/

/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main( void ){

   // ---------- CONFIGURACIONES ------------------------------

   // Inicializar y configurar la plataforma
   boardConfig();

   // Inicializar UART_USB a 115200
   uartConfig( UART_USB, 115200 );
    
   uint8_t datoRecibido;


   // ---------- REPETIR POR SIEMPRE --------------------------
   while( TRUE )
   {
      if( uartReadByte( UART_USB, &datoRecibido )) { // Si recibo caracter por uart
          switch(datoRecibido){                      // conmuta el estado del led
              case'a':                               // con gpioToggle
                  gpioToggle( LEDB );
              break;
              case'v':
                  gpioToggle( LEDG );
              break;
              case'r':
                  gpioToggle( LEDR );
              break;
              case'1':
                  gpioToggle( LED1 );
              break;
              case'2':
                  gpioToggle( LED2 );
              break;
              case'3':
                  gpioToggle( LED3 );
              break;
              default:
              break;
          }
      }
              
      if( gpioRead( LEDR ) == ON ){
         consolePrintlnString( "LEDR encendido." );
      } else{
         consolePrintlnString( "LEDR apagado." );
          }
      if( gpioRead( LEDG ) == ON ){
         consolePrintlnString( "LEDG encendido." );
      } else{
         consolePrintlnString( "LEDG apagado." );
          }
      if( gpioRead( LEDB ) == ON ){
         consolePrintlnString( "LEDB encendido." );
      } else{
         consolePrintlnString( "LEDB apagado." );
          }
      if( gpioRead( LED1 ) == ON ){
         consolePrintlnString( "LED1 encendido." );
      } else{
         consolePrintlnString( "LED1 apagado." );
          }
      if( gpioRead( LED2 ) == ON ){
         consolePrintlnString( "LED2 encendido." );
      } else{
         consolePrintlnString( "LED2 apagado." );
          }
      if( gpioRead( LED3 ) == ON ){
         consolePrintlnString( "LED3 encendido." );
      } else{
         consolePrintlnString( "LED3 apagado." );
          }
       if( !gpioRead( TEC4 ) == ON ){
         consolePrintlnString( "TEC4 pulsada." );
      } else{
         consolePrintlnString( "TEC4 soltada." );
          }
        if( !gpioRead( TEC3 ) == ON ){
         consolePrintlnString( "TEC3 pulsada." );
      } else{
         consolePrintlnString( "TEC3 soltada." );
          }
        if( !gpioRead( TEC2 ) == ON ){
         consolePrintlnString( "TEC2 pulsada." );
      } else{
         consolePrintlnString( "TEC2 soltada." );
          }
        if( !gpioRead( TEC1 ) == ON ){
         consolePrintlnString( "TEC1 pulsada." );
      } else{
         consolePrintlnString( "TEC1 soltada." );
          }
                                            // Limpia pantalla terminal
                                            // No anda bien????!!!!
       uartWriteByte( UART_USB, 27 );       // ESC command
       uartWriteString( UART_USB, "[2J" );  // Clear screen command
       uartWriteByte( UART_USB, 27 );       // ESC command
       uartWriteString( UART_USB, "[H" );   // Cursor to home command 
       delay( 1000 );                       // Retardo 1 seg
    }
   return 0;
     
}

/*==================[definiciones de funciones internas]=====================*/

/*==================[definiciones de funciones externas]=====================*/

/*==================[fin del archivo]========================================*/