/*============================================================================
 * Licencia:
 * Autor:
 * Fecha:
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

//#include "program.h"   // <= su propio archivo de cabecera (opcional)
#include "sapi.h"        // <= Biblioteca sAPI

//#include "c_i18n_es.h" // <= para traducir el codigo C al espa�ol (opcional)
//#include "c_i18n_es.h" // <= para traducir la sAPI al espa�ol (opcional)

/*==================[definiciones y macros]==================================*/

#define CANTIDAD_DE_RONDAS 10   // Define la cantidad de ciclos de encendido para el juego simon dice
                                // Es la cantidad de caracteres de la secuencia de inicio
typedef enum{ 
  RECIBIENDO_SECUENCIA, 
  REPRODUCIENDO_SECUENCIA, 
  INGRESANDO_SECUENCIA
} estado_t;

void inicializarMEF( void );

void actualizarMEF( void );

void IngresarCaracterUart(void);

void LecturaBotones(void);

void EncendidoSecuenciaLeds(void);

void Blinkeo(void);


/*==================[definiciones de datos internos]=========================*/

CONSOLE_PRINT_ENABLE

/*==================[definiciones de datos externos]=========================*/

   // Crear  variables  globales
   uint8_t datoRecibido;
   uint8_t numeroCaracter;
   uint8_t NumeroLedsaReproducir;
   uint8_t  blinkeo;

   bool_t CaracterNoIngresado = OFF;
   bool_t Error = OFF;
   bool_t error = OFF;
   bool_t TeclaIngresada = OFF;
   
   estado_t  estadoActual;
   
    char secuencia[ CANTIDAD_DE_RONDAS ]; // secuencia es un arreglo de  10 caracteres
    char teclaIngresada ;

/*==================[declaraciones de funciones internas]====================*/

/*==================[declaraciones de funciones externas]====================*/

/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main( void ){

   // ---------- CONFIGURACIONES ------------------------------

   // Inicializar y configurar la plataforma
   boardConfig();

   // Inicializar UART_USB a 115200
   uartConfig( UART_USB, 115200 );

      inicializarMEF();
   
   // ---------- REPETIR POR SIEMPRE --------------------------
   while( TRUE )
   {
      actualizarMEF();
   }

   // NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa se ejecuta
   // directamenteno sobre un microcontroladore y no es llamado por ningun
   // Sistema Operativo, como en el caso de un programa para PC.
   return 0;
}

void inicializarMEF( void ){
   estadoActual = RECIBIENDO_SECUENCIA;
}


void actualizarMEF( void ){
   switch( estadoActual ){
   
      case RECIBIENDO_SECUENCIA:
         // Actualizar la salida en el estado
     
         gpioWrite( LED2, ON  ); // Enciendo tres segundos led Rojo
          delay(3000);
         gpioWrite( LED2, OFF );
      
      consolePrintString( "Ingrese 10");
      consolePrintlnString("caracteres para encendido de secuencia de leds" );
      consolePrintlnString( "En juego SIMON DICE" );
      consolePrintlnString( "Son solo v�lidos los caracteres a(LedBlue) 1(Led1) 2(Led2) 3(Led3) " );
      
       for (numeroCaracter=0;numeroCaracter<CANTIDAD_DE_RONDAS;numeroCaracter++) {
      CaracterNoIngresado=true;   
      while(CaracterNoIngresado){     // Queda en bucle mientras CaracterNoIngresado sea true
            IngresarCaracterUart();   // Cuando se ingresa un caracter valido por uart CaracterNoIngresado pasa a ser false
      }                               // Entonces sale del while y sigue el ciclo for
     }
         
         // Chequear condiciones de transicion de estado
         consolePrintlnString( "Secuencia correcta ingresada" );
         consolePrintlnString( "Comienzo del Juego" );
         consolePrintlnString( "Simon DICE" );
            estadoActual = REPRODUCIENDO_SECUENCIA;
            NumeroLedsaReproducir= 0;        // Sale del estado con valor cero de leds a reproducir
     
     Blinkeo();          // Hace blinkear los 4 leds cuatro veces 
                             //  indica que se ingreso correctamente la secuencia
                            //  y comienza el juego
         break;
   
      
         
         case REPRODUCIENDO_SECUENCIA:
         // Actualizar la salida en el estado
         
         NumeroLedsaReproducir++;     // Incrementa el numero de leds a reproducir
         EncendidoSecuenciaLeds();
         
         // Chequear condiciones de transicion de estado
            
            estadoActual = INGRESANDO_SECUENCIA;
      
      break;
   
      case INGRESANDO_SECUENCIA:
         // Actualizar la salida en el estado
        numeroCaracter=0 ;
        Error=false;
       while(!Error && (numeroCaracter<NumeroLedsaReproducir))  {  // Se mantiene leyendo un boton mientras
                                                                   // No exista error y el numeroCaracter<NumeroLedsaReproducir
            LecturaBotones();    // Lee un boton                   
          if ( secuencia[numeroCaracter] != teclaIngresada ) {   // Compara el valor ingresado con la secuencia
              Error = true;                                      // Si es distinto  Error = true
              consolePrintlnString( "Has ingresado un led incorrecto" ); //Mensaje perdedor de fin de juego
              consolePrintlnString( "Has perdido" );
              estadoActual = RECIBIENDO_SECUENCIA;                       //y reinicia el juego
              }
            numeroCaracter++;  // Incremento para barrer todo el array
          }
          
          // Chequear condiciones de transicion de estado    
       
          if(!Error) {                                                 // Si no hay error da el mensaje de que 
              consolePrintlnString( "BIEN!!" );                        // se ingreso bien la secuencia
          consolePrintlnString( "Has Completado la secuencia" );    
          estadoActual = REPRODUCIENDO_SECUENCIA; }                    // Pasa a reproducir la secuencia

          if (numeroCaracter==CANTIDAD_DE_RONDAS) {                    //Si el n�mero de caracter
              consolePrintlnString( "EXCELENTE!!!!!!" );               //es igual a CANTIDAD_DE_RONDAS
              consolePrintlnString( "Has GANADO!!!!!" );               //Mensaje ganador de fin de juego
              estadoActual = RECIBIENDO_SECUENCIA;                     //y reinicia el juego
              }
      break;
   }
}

/*==================[definiciones de funciones internas]=====================*/



void IngresarCaracterUart(void){                          // Cuando se ingresa un caracter valido por uart 
                                                          // CaracterNoIngresado pasa a ser false
     if( uartReadByte( UART_USB, &datoRecibido )) {       // Si recibo caracter por uart
          switch(datoRecibido){                           // Lo guardo en el array secuencia
              case'a':                                    //
                  secuencia[ numeroCaracter ]=datoRecibido;
                  CaracterNoIngresado=false;
              break;
              case'1':
                  secuencia[ numeroCaracter ]=datoRecibido;
                  CaracterNoIngresado=false;
              break;
              case'2':
                  secuencia[ numeroCaracter ]=datoRecibido;
                  CaracterNoIngresado=false;
              break;
              case'3':
                  secuencia[ numeroCaracter ]=datoRecibido;
                  CaracterNoIngresado=false;
              break;
              default:
                  error=true;
              break;
             }
          
          if (error) {
              
          consolePrintlnString( "Error-ingreso un caracter inv�lido" );
          consolePrintlnString( "Vuelva a ingresar un caracter v�lido" );
              error=false;
            }
         uartWriteByte( UART_USB, datoRecibido); 
       }
   }
   
   
   void LecturaBotones(void){
       TeclaIngresada=false;
       while(!TeclaIngresada){
            
           if (!gpioRead( TEC1 )){
           delay(50);
           if (!gpioRead( TEC1 )){
               teclaIngresada = 'a';
             TeclaIngresada=true;
            gpioWrite( LEDB, ON ); 
            delay(500);
            gpioWrite( LEDB, OFF );
               }
               };
             
             
             
           if (!gpioRead( TEC2 )){
            delay(50);
           if (!gpioRead( TEC2 ))
           {  teclaIngresada = '1';
            TeclaIngresada=true;
            gpioWrite( LED1, ON ); 
            delay(500);
            gpioWrite( LED1, OFF );}};
            
            
        
            if (!gpioRead( TEC3 )){
            delay(50);
            if (!gpioRead( TEC3 ))
            { teclaIngresada = '2';
             TeclaIngresada=true;
            gpioWrite( LED2, ON ); 
            delay(500);
            gpioWrite( LED2, OFF );}};
             
             
        
            if (!gpioRead( TEC4 )){
            delay(50);
            if (!gpioRead( TEC4 ))
            { teclaIngresada = '3';
            TeclaIngresada=true;
            gpioWrite( LED3, ON ); 
            delay(500);
            gpioWrite( LED3, OFF );}};
            
            
          }
      }
       
   void EncendidoSecuenciaLeds(void){
       for (numeroCaracter=0;numeroCaracter<NumeroLedsaReproducir;numeroCaracter++)
          switch(secuencia[ numeroCaracter ]){       // Enciendo los leds de acuerdo a la secuencia guardada
              case'a':                               //
                  delay(1000); 
                  gpioWrite( LEDB, ON ); // Enciende y apaga led azul
                  delay(1000);
                  gpioWrite( LEDB, OFF );
              break;
              case'1':
                  delay(1000);
                  gpioWrite( LED1, ON ); // Enciende y apaga led 1
                  delay(1000);
                  gpioWrite( LED1, OFF );
              break;
              case'2':
                  delay(1000); 
                  gpioWrite( LED2, ON ); // Enciende y apaga led 2
                  delay(1000);
                  gpioWrite( LED2, OFF );
              break;
              case'3':
                  delay(1000);
                  gpioWrite( LED3, ON );  // Enciende y apaga led 3 
                  delay(1000);
                  gpioWrite( LED3, OFF );   
              break;   
            }
        }
        
        void Blinkeo(void){
             for (blinkeo=0;blinkeo<4;blinkeo++) // Hace blinkear los 4 leds cuatro veces 
         {                                       //  indica que se ingreso correctamente la secuencia
                                                 //  y comienza el juego
         gpioWrite( LED3, ON );  //  
         gpioWrite( LED2, ON  ); // 
         gpioWrite( LED1, ON  ); // 
         gpioWrite( LEDG, ON ); // 
      
         delay(500);
         
         gpioWrite( LED3, OFF );  
         gpioWrite( LED2, OFF  ); // 
         gpioWrite( LED1, OFF  ); // 
         gpioWrite( LEDG, OFF ); // 
             
         }
         
     }
            
       
/*==================[definiciones de funciones externas]=====================*/

/*==================[fin del archivo]========================================*/