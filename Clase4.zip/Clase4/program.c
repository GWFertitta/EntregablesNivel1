/*============================================================================
 * Licencia:
 * Autor: Walter Guillermo Fertitta
 * Fecha: 01/09/17
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

//#include "program.h"   // <= su propio archivo de cabecera (opcional)
#include "sapi.h"        // <= Biblioteca sAPI

//#include "c_i18n_es.h" // <= para traducir el codigo C al espa�ol (opcional)
//#include "c_i18n_es.h" // <= para traducir la sAPI al espa�ol (opcional)

/*==================[definiciones y macros]==================================*/

/*==================[definiciones de datos internos]=========================*/

CONSOLE_PRINT_ENABLE

/*==================[definiciones de datos externos]=========================*/

/*==================[declaraciones de funciones internas]====================*/

/*==================[declaraciones de funciones externas]====================*/

/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main( void ){

   // ---------- CONFIGURACIONES ------------------------------

   // Inicializar y configurar la plataforma
   boardConfig();

   // Inicializar UART_USB como salida de consola
   consolePrintConfigUart( UART_USB, 115200 );

   // Crear  variables 
   bool_t tec1Value = OFF;  // Variable booleana para leer la tecla
   int  Contador = 0 ;      // Variable entera para contar los milisegundos
    
   // ---------- REPETIR POR SIEMPRE --------------------------
   while( TRUE )
   {
     Contador = 0 ;// Setea contador a cero
       // Leer pin conectado a la tecla.
      tec1Value = gpioRead( TEC2 );
       // Invertir el valor leido, pues lee un 0 (OFF) con tecla
      // presionada y 1 (ON) al liberarla.
      tec1Value = !tec1Value;
       if( tec1Value == ON ) //Ingresa a esta rama del programa si esta pulsado el boton 2
       { while ( tec1Value == ON )//Incrementa el contador mientras este el boton 2 presionado
           {
             Contador++ ; // Incrementa contador de milisegundos
             delay( 1 ); // Retardo de 1 milisegundo
             tec1Value = gpioRead( TEC2 );// Lee en cada ciclo de cuenta el boton 2
             tec1Value = !tec1Value;
               
             }
         
         gpioWrite( LED1, ON ); // Enciende el led cuando se suelta el boton 2
         delay( Contador ); // Espera los milisegundos contados
         gpioWrite( LED1, OFF ); // Lo apaga luego de que pasa el tiempo contado 
             
       }
   }

   // NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa se ejecuta
   // directamenteno sobre un microcontroladore y no es llamado por ningun
   // Sistema Operativo, como en el caso de un programa para PC.
   return 0;
}

/*==================[definiciones de funciones internas]=====================*/

/*==================[definiciones de funciones externas]=====================*/

/*==================[fin del archivo]========================================*/