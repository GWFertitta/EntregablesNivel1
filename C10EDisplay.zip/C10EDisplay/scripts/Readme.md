# En Linux se debe dar permiso de ejecución a los script

cd /path/to/project/scripts
sudo chmod +x ScriptName.sh