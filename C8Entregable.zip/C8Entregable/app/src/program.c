/*============================================================================
 * Licencia:
 * Autor: Fertitta, Walter Guillermo
 * Fecha: 15/09/17
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

//#include "program.h"   // <= su propio archivo de cabecera (opcional)
#include "sapi.h"        // <= Biblioteca sAPI

//#include "c_i18n_es.h" // <= para traducir el codigo C al espa�ol (opcional)
//#include "c_i18n_es.h" // <= para traducir la sAPI al espa�ol (opcional)

/*==================[definiciones y macros]==================================*/

/*==================[definiciones de datos internos]=========================*/

CONSOLE_PRINT_ENABLE

/*==================[definiciones de datos externos]=========================*/

/*==================[declaraciones de funciones internas]====================*/

/*==================[declaraciones de funciones externas]====================*/

/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main( void ){

   // ---------- CONFIGURACIONES ------------------------------

  // Inicializar y configurar la plataforma


boardConfig();

//  Inicializar ADC y DAC 

adcConfig(ADC_ENABLE);
dacConfig(DAC_ENABLE);
    
      // Inicializar UART_USB como salida de consola
   uartConfig( UART_USB, 115200 );

   // Crear  variables 
uint8_t receivedByte;
    
uint8_t Control = '1' ;  // Variable para conmutar el control 1 Pote 2 UART 3 Pulsadores
        
bool_t valor = 0;

uint8_t servoAngle = 0; /* 0 a 180 grados */  
      
    /* Configurar Servo */
valor = servoConfig( 0, SERVO_ENABLE );

valor = servoConfig( SERVO0, SERVO_ENABLE_OUTPUT );

   /* Usar Servo */
valor = servoWrite( SERVO0, servoAngle );
servoAngle = servoRead( SERVO0 );



bool_t ledState1 = OFF;

uint16_t muestra = 0;  // Variable muestra del pote

   // ---------- REPETIR POR SIEMPRE --------------------------
   
 
 while( TRUE )
   {
     
       
       uartReadByte( UART_USB,  &receivedByte );
     if ( receivedByte == '1' || receivedByte == '2' || receivedByte == '3' ){
    Control = receivedByte ;};
    
    if ( Control == '1' ) {   // Control Potenciometro
        uartWriteString(UART_USB,"Control Potenciometro");
        muestra = adcRead (CH2);
      servoWrite( SERVO0, (muestra*180)/1023 );
   }
   
   if ( Control == '2' ) {    // Control UART
       uartWriteString(UART_USB,"Control UART");
         if (uartReadByte( UART_USB,  &receivedByte )){
    switch (receivedByte){
        case'a':
             servoWrite( SERVO0, 5 );
             uartWriteString(UART_USB,"5 Grados");
        break;
        case'b':
             servoWrite( SERVO0, 60 );
             uartWriteString(UART_USB,"60 grados");
        break;
        case'c':
             servoWrite( SERVO0, 120 );
             uartWriteString(UART_USB,"120 grados");
        break;
        case'd':
             servoWrite( SERVO0, 180 );
             uartWriteString(UART_USB,"180 grados");
        break;
        default:
            uartWriteString(UART_USB,"OPCION NO VALIDA");
        break;}
   }
   }
   
   if ( Control == '3' ) {   // Control Pulsador
       uartWriteString(UART_USB,"Control Pulsador");
        if (!gpioRead( TEC1 )) {
          servoWrite( SERVO0, 10 );
          delay(500);
      };

     if (!gpioRead( TEC2 )) {
          servoWrite( SERVO0, 60 );
         delay(500);
      };
    
     if (!gpioRead( TEC3 )) {
          servoWrite( SERVO0, 120 );
         delay(500);
      };
    
     if (!gpioRead( TEC4 )) {
          servoWrite( SERVO0,180 );
         delay(500);
      };
  }
        
 uartWriteByte( UART_USB, 27 ); // ESC command
 uartWriteString( UART_USB, "[2J" ); // Clear screen command
 uartWriteByte( UART_USB, 27 ); // ESC command
 uartWriteString( UART_USB, "[H" ); // Cursor to home command
 
        
  
       
      
       
   }

   // NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa se ejecuta
   // directamenteno sobre un microcontroladore y no es llamado por ningun
   // Sistema Operativo, como en el caso de un programa para PC.
   return 0;
}

/*==================[definiciones de funciones internas]=====================*/

/*==================[definiciones de funciones externas]=====================*/

/*==================[fin del archivo]========================================*/