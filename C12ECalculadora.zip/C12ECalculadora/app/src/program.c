/*============================================================================
 * Licencia: 
 * Autor: Guillermo Fertitta
 * Fecha: 
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

#include "sapi.h"       // <= Biblioteca sAPI

/*==================[definiciones y macros]==================================*/

CONSOLE_PRINT_ENABLE

typedef enum{ 
   INGRESO_NUMERO_1, 
   INGRESO_NUMERO_2, 
   RESULTADO
} estado_t;

typedef enum{ 
   suma, 
   resta, 
   multiplicacion,
   division
} operacion_t;


/*==================[definiciones de datos internos]=========================*/
estado_t estadoActual;

operacion_t operacion;

uint16_t  a,i,m,n, numero1,numero2 ;

int32_t   Resultado;

float ResultadoDivision;



bool_t Operacion,Correccion,carga;

uint16_t   ArrayNumero1[3]={0,0,0};
uint16_t   ArrayNumero2[3]={0,0,0};


uint16_t   arrayNumero1[3]={0,0,0};
uint16_t   arrayNumero2[3]={0,0,0};







/*==================[definiciones de datos externos]=========================*/



// Guarda la ultima tecla apretada
uint16_t key = 0;

/* Pines del teclado matricial */

// Pines conectados a las Filas --> Salidas (MODO = OUTPUT)
uint8_t keypadRowPins[4] = {
   RS232_TXD, // Row 0
   CAN_RD,    // R1
   CAN_TD,    // R2
   T_COL1     // R3
};

// Pines conectados a las Columnas --> Entradas con pull-up (MODO = INPUT_PULLUP)
uint8_t keypadColPins[4] = {
   T_FIL0,    // Column 0
   T_FIL3,    // C1
   T_FIL2,    // C2
   T_COL0     // C3
};


// Vector para mostrar tecla presionada por UART
uint16_t asciiKeypadKeys[16] = {
                                '1', '2', '3', 'A',
                                '4', '5', '6', 'B',
                                '7', '8', '9', 'C',
                                '*', '0', '#', 'D'
                               };

// Vector para mostrar tecla presionada en el display 7 segmentos
uint16_t keypadKeys[16] = {
                               1,    2,    3, 0x0a,
                               4,    5,    6, 0x0b,
                               7,    8,    9, 0x0c,
                            0x0e,    0, 0x0f, 0x0d
                          };
                          
                          
/*==================[declaraciones de funciones internas]====================*/
 void inicializarMEF(void);
 void actualizarMEF(void);

/*==================[declaraciones de funciones externas]====================*/

void configurarTecladoMatricial( void );
bool_t leerTecladoMatricial( void );                

/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main( void ){

   // ---------- CONFIGURACIONES ------------------------------
   boardConfig(); // Inicializar y configurar la plataforma  
   uartConfig( UART_USB, 115200 ); // Configurar UART a 115200 
  
   configurarTecladoMatricial(); // Configurar teclado matricial
    
   inicializarMEF();  // Inicializar MEF
      
   // ---------- REPETIR POR SIEMPRE --------------------------
   while( TRUE )
   {
      
       actualizarMEF();
       
       //if( leerTecladoMatricial() ){
       //  uartWriteByte( UART_USB, asciiKeypadKeys[key] );
       //  delay(50);
      //}
   } 

   // NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa se ejecuta 
   // directamenteno sobre un microcontroladore y no es llamado/ por ningun
   // Sistema Operativo, como en el caso de un programa para PC.
   return 0;
}

/*==================[definiciones de funciones internas]=====================*/
void inicializarMEF(void){
    estadoActual = INGRESO_NUMERO_1;
}
 // INGRESO_NUMERO_1, 
 //  INGRESO_NUMERO_2, 
 //  RESULTADO  


void actualizarMEF( void ){
   switch( estadoActual ){
   
      case INGRESO_NUMERO_1:
          
      for (i=0;i<3;i++){              //Puesta a cero vector de carga de numero 1
          ArrayNumero1[i]=0;
          
      }
         // Actualizar la salida en el estado
      consolePrintlnString("CALCULADORA");
      consolePrintlnString("(A) Suma,(B) Resta,(C) Division y (D) multiplicaci�n");
      consolePrintlnString("de n�meros de hasta 3 cifras");
      consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
      consolePrintlnString("Ingrese * para volver a ingresar el n�mero ");
      
      i=0;
      Operacion=false;
      Correccion=false;
      while (Operacion==false){       //Ingreso por teclado numero 1
          
          //consolePrintlnString("Ingrese cifra");
          carga=false;
        while(!carga){
       
          if( leerTecladoMatricial() ){
              delay(20);                      //Agrega delay como un antirrebote simple
              if( leerTecladoMatricial() ){
              switch(asciiKeypadKeys[key]){
                  case 'A':
                      operacion=suma; //Suma
                      consolePrintlnString("+");
                      Operacion=true;
                      carga=true;
                      if(i==0){
                           Operacion=false;
                           consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
                      }
                          
                  break;
                  case 'B':
                     operacion=resta; //Resta
                     consolePrintlnString("-");
                      Operacion=true;
                      carga=true;
                      if(i==0){
                           Operacion=false;
                           consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
                      }
                  break;
                  case 'C':
                      operacion=multiplicacion; //Multiplicaci�n
                      consolePrintlnString("*");
                      Operacion=true;
                      carga=true;
                      if(i==0){
                           Operacion=false;
                           consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
                      }
                  break;
                  case 'D':
                      operacion=division;//Divisi�n
                      consolePrintlnString("/");
                      Operacion=true;
                      carga=true;
                      if(i==0){
                           Operacion=false;
                           consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
                      }
                  break;
                  case '*':
                      
                      i=-1;
                      Operacion=true;
                      Correccion=true;
                      consolePrintlnString("Correcci�n");
                      carga=true;
                        
                  break;
                  default:
                      if(i<3){
                      ArrayNumero1[i]=asciiKeypadKeys[key];
                      uartWriteByte( UART_USB, asciiKeypadKeys[key] );
                    //consolePrintlnString("");
                      carga=true;
                      }
                      if(i==3){
                          consolePrintlnString("Por favor ingrese (A) Suma,(B) Resta,(C) Division y (D) multiplicaci�n");
            
                          }
                      //
                      //ver tema si despues de ingresar 3 numeros, sigue ingresando numeros en vez de operacion
                  break;
              }
          }
        }
       }
       
       if(Operacion==false)
             i++;
      }        
              
      i--;
    
      // Chequear condiciones de transicion de estado
    
      if(Operacion==true)
        estadoActual=INGRESO_NUMERO_2;          //Si carga bien numero1 pasa a cargar el n�mero2
      
      if(Correccion==true)
        estadoActual=INGRESO_NUMERO_1;          //Si se ingreso la correcci�n vuelve a cargar el n�mero1
            
      break;
      
    //-----------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------
   
   
      case INGRESO_NUMERO_2:
          
         // Actualizar la salida en el estado
      for (a=0;a<3;a++){                               // Puesta a cero del vector de carga de n�mero 2
          ArrayNumero2[a]=0;
          
      }
      
    
      a=0;
      Operacion=false;
      Correccion=false;
      
          consolePrintlnString("Ingrese numero 2");
          consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
          consolePrintlnString("ingrese # para hacer la operaci�n");
          consolePrintlnString("Ingrese * para volver a ingresar el n�mero ");
       
      
       while (Operacion==false){                 //Ingreso por teclado numero 2
          
           carga=false;
         while(!carga){
          if( leerTecladoMatricial() ){
              delay(20);                      //Agrega delay para tener un antirrebote simple
              if( leerTecladoMatricial() ){
              switch(asciiKeypadKeys[key]){
                  case 'A':
                  case 'B':
                  case 'C':
                  case 'D':
                      if(a==0){
                           Operacion=false;
                           consolePrintlnString("Ingrese por teclado un n�mero de hasta 3 cifras");
                      };
                      if(a>0&&a<3){
                           Operacion=false;
                           consolePrintlnString("ingrese cifra o # para hacer la operaci�n");
                      };
                      if(a==3){
                           Operacion=false;
                           consolePrintlnString("ingrese # para hacer la operaci�n");
                          
                      };
                      
                  break;
                  case '#':
                      consolePrintlnString("=");
                      Operacion=true;
                      Correccion=false;
                      carga=true;
                      a--;
                      
                      
                  break;
                  case '*':
                      
                      Operacion=true;
                      Correccion=true;
                      consolePrintlnString("Correcci�n");
                      carga=true;
                         
   
                      
                  break;
                  default:
                       if(a<3){
                      ArrayNumero2[a]=asciiKeypadKeys[key];
                      uartWriteByte( UART_USB, asciiKeypadKeys[key] );
                      carga=true;
                       }
                      if(a==3){
                           consolePrintlnString("ingrese # para hacer la operaci�n");
                      }
                      
                      
                  break;
                }
            }
         }
        }
         if (Operacion==false){
              a++;
         }
    }
    
         // Chequear condiciones de transicion de estado
      if(Operacion==true){
          estadoActual=RESULTADO;            //Si cargo el numero 2 correctamente pasa a calcular el resultado
          }
      
      if(Correccion==true)
          estadoActual=INGRESO_NUMERO_2;     //Si se ingres� la tecla correcci�n vuelve a ingresar numero 2
      
      
         
      break;
      
      
      //-----------------------------------------------------------------------------------------------------------
      //-------------------------------------------------------------------------------------------------------------
   
      case RESULTADO:
         // Actualizar la salida en el estado
      
  
      
      
      for (m=0;m<3;m++){
          arrayNumero1[m]=0;
          //consolePrintlnInt(ArrayNumero1[m])
          };
      
     for (m=0;m<3;m++){
          arrayNumero2[m]=0;
        //consolePrintlnInt(ArrayNumero2[m])        // Puesta a cero de los vectores donde se cargan los n�meros
        };                                          // 
          
          
       arrayNumero2[0]=ArrayNumero2[a]-48;             //Resta 48 a los n�meros que se tienen en los vectores de ingreso
       //consolePrintlnInt(Numero2[0]);                // ya que son char en codigo ascii
       m=0;                                            //(Para transformarlos en enteros)
      while(a>0){
       
                 m++;
                 a--;
                 if(m==1)
                 arrayNumero2[m]=10*(ArrayNumero2[a]-48);
                 if(m==2)
                 arrayNumero2[m]=100*(ArrayNumero2[a]-48); //Multiplica por 10 decenas y por 100 centenas
                 //consolePrintlnInt(Numero2[m]);
         };
         
         
     
    
      arrayNumero1[0]=ArrayNumero1[i]-48;
     // consolePrintlnInt(Numero1[0]);
        m=0;   
       while(i>0){
          i--;
          m++;
        
                if(m==1)
                 arrayNumero1[m]=10*(ArrayNumero1[i]-48);
               
                 if(m==2)
                 arrayNumero1[m]=100*(ArrayNumero1[i]-48);
                 
                  //consolePrintlnInt(Numero1[m]);

          };
       
       for (m=0;m<3;m++){
          //Numero1[i]=0;
           //consolePrintlnInt(arrayNumero1[m]);
           //consolePrintlnString("Numero1");
       };
      
      for (m=0;m<3;m++){
          //Numero2[i]=0;
          //consolePrintlnInt(arrayNumero2[m]);
          // consolePrintlnString("Numero2");
          
      };
       numero1=0;
       numero2=0;
       for(m=0;m<3;m++){
           numero1= numero1+arrayNumero1[m];            //Suma los vectores para obtener los numeros completos
           
           numero2= numero2+arrayNumero2[m];
       };
       consolePrintInt(numero1);
    
       
              
              switch(operacion){                      // De acuerdo a la operaci�n la ejecuta e imprime el resultado
             case suma :
                 
                 consolePrintString("+");
                 consolePrintInt(numero2);
                 consolePrintString("=");
                 Resultado=numero1+numero2;
                 consolePrintlnInt(Resultado); 
                 
             break;
             case resta :
                 consolePrintString("-");
                 consolePrintInt(numero2);
                 consolePrintString("=");
                Resultado=numero1-numero2;
                consolePrintlnInt(Resultado); 
             
             break;
             case multiplicacion :
                 consolePrintString("*");
                 consolePrintInt(numero2);
                 consolePrintString("=");
                 Resultado=numero1*numero2;
                 consolePrintlnInt(Resultado); 
             
             break;
             case division :
                 consolePrintString("/");
                 consolePrintInt(numero2);
                 consolePrintString("=");
                 ResultadoDivision=((float)numero1)/numero2;   // Castea para obtener un resultado float
                                                               // La divisi�n de dos enteros da un entero
                                                               // Por eso en numerador debe ser float
             Resultado=(int)ResultadoDivision;               //Se queda en resultado solo con la parte entera
             ResultadoDivision=ResultadoDivision-Resultado;  // Resta resultado para tener solo la parte decimal
             
              consolePrintInt(Resultado); 
              uartWriteByte( UART_USB, 46 );
             consolePrintlnInt((int)(ResultadoDivision*10000)); //Solo imprime enteros
                                                                //Asi que multiplica por 10000 para tener 4 decimales
             
             break;
         };
         
         // Chequear condiciones de transicion de estado
       estadoActual=INGRESO_NUMERO_1;
         
      break;
   
    };
  }


/*==================[definiciones de funciones externas]=====================*/

void configurarTecladoMatricial( void ){
   
   uint8_t i = 0;
   
   // Configure Rows as Outputs
   for( i=0; i<4; i++ ){
      gpioConfig( keypadRowPins[i], GPIO_OUTPUT );
   }

   // Configure Columns as Inputs with pull-up resistors enable
   for( i=0; i<4; i++ ){
      gpioConfig( keypadColPins[i], GPIO_INPUT_PULLUP );
   }
}


/* Devuelve TRUE si hay alguna tecla presionada o FALSE (0) en caso contrario.
 * Si hay tecla presionada guarda el valor en la variable key.
 * El valor es un numero de indice entre 0 y 15 */
bool_t leerTecladoMatricial( void ){

   bool_t retVal = FALSE;

   uint16_t r = 0; // Rows
   uint16_t c = 0; // Columns

   // Poner todas las filas en estado BAJO
   for( r=0; r<4; r++ ){
	  gpioWrite( keypadRowPins[r], LOW );
   }

   // Chequear todas las columnas buscando si hay alguna tecla presionada
   for( c=0; c<4; c++ ){

      // Si leo un estado BAJO en una columna entonces puede haber una tecla presionada
      if( !gpioRead( keypadColPins[c] ) ){

         delay( 70 ); // Anti-rebotes de 50 ms

         // Poner todas las filas en estado ALTO excepto la primera
         for( r=1; r<4; r++ ){
            gpioWrite( keypadRowPins[r], HIGH );
         }

         // Buscar que tecla esta presionada
         for( r=0; r<4; r++ ){

            // Poner la Fila[r-1] en estado ALTO y la Fila[r] en estado BAJO
            if( r>0 ){ // Exceptua el indice negativo en el array
               gpioWrite( keypadRowPins[r-1], HIGH );
            }
            gpioWrite( keypadRowPins[r], LOW );

            // Chequear la Columna[c] en Fila[r] para buscar si la tecla esta presionada
            // Si dicha tecla esta oresionada (en estado BAJO) entonces retorna
            // graba la tecla en key y retorna TRUE
            if( !gpioRead( keypadColPins[c] ) ){
               retVal = TRUE;
               key = r * 4 + c;
               /*
                  Formula de las teclas de Teclado Matricial (Keypad)
                  de 4 filas (rows) * 5 columnas (columns)

                     c0 c1 c2 c3 c4
                  r0  0  1  2  3  4
                  r1  5  6  7  8  9   Si se presiona la tecla r[i] c[j]:
                  r2 10 11 12 13 14   valor = (i) * cantidadDeColumnas + (j)
                  r3 15 16 17 18 19
               */
               return retVal;
            }
         }

      }
   }
   return retVal;
}

/*==================[fin del archivo]========================================*/  